## Packages
(none needed)

## Notes
- Using lucide-react for icons instead of react-icons
- Framer Motion used for slide-out animations
- CSS variables --fill-1 through --fill-6 are CRITICAL for SVG coloring
- Backend expects POST /api/ai/suggest for AI features
